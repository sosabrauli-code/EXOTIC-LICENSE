create extension if not exists pgcrypto;
create table if not exists public.license_admins(user_id uuid primary key references auth.users(id) on delete cascade,created_at timestamptz default now());
create table if not exists public.licenses(id uuid primary key default gen_random_uuid(),client_name text not null,resource_name text not null,license_key text unique not null,duration_days integer,expires_at timestamptz,status text not null default 'active' check(status in ('active','revoked')),created_at timestamptz default now());
alter table public.license_admins enable row level security;
alter table public.licenses enable row level security;
